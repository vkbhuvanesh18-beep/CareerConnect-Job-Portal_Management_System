-- ===================================================================
-- Job Portal Management System - Database Script
-- Run this entire file in MySQL Workbench / mysql command line
-- ===================================================================

CREATE DATABASE IF NOT EXISTS job_portal_db;
USE job_portal_db;

-- ---------------------------------------------------------
-- Table: users  (stores Admin, Employer, and Job Seeker accounts)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    role VARCHAR(20) NOT NULL,          -- ADMIN, EMPLOYER, SEEKER
    phone VARCHAR(15),
    company_name VARCHAR(100),          -- used only for EMPLOYER role
    created_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------
-- Table: jobs  (job postings created by employers)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS jobs (
    job_id INT AUTO_INCREMENT PRIMARY KEY,
    employer_id INT NOT NULL,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    company_name VARCHAR(100),
    location VARCHAR(100),
    salary VARCHAR(50),
    job_type VARCHAR(30),               -- Full-Time, Part-Time, Internship
    posted_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employer_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- ---------------------------------------------------------
-- Table: applications  (job seekers applying to jobs)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS applications (
    app_id INT AUTO_INCREMENT PRIMARY KEY,
    job_id INT NOT NULL,
    seeker_id INT NOT NULL,
    applied_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'PENDING',  -- PENDING, SHORTLISTED, REJECTED
    FOREIGN KEY (job_id) REFERENCES jobs(job_id) ON DELETE CASCADE,
    FOREIGN KEY (seeker_id) REFERENCES users(user_id) ON DELETE CASCADE,
    UNIQUE KEY unique_application (job_id, seeker_id)  -- prevents duplicate applications
);

-- ---------------------------------------------------------
-- Default Admin account (login with this to access Admin Dashboard)
-- Email: admin@jobportal.com | Password: admin123
-- ---------------------------------------------------------
INSERT INTO users (name, email, password, role, phone)
VALUES ('System Admin', 'admin@jobportal.com', 'admin123', 'ADMIN', '9999999999')
ON DUPLICATE KEY UPDATE name = name;

-- ---------------------------------------------------------
-- Sample Employer + Job Seeker + Job posting (optional test data)
-- ---------------------------------------------------------
INSERT INTO users (name, email, password, role, phone, company_name)
VALUES ('Ravi Kumar', 'employer@test.com', 'emp123', 'EMPLOYER', '9876543210', 'TechSoft Solutions')
ON DUPLICATE KEY UPDATE name = name;

INSERT INTO users (name, email, password, role, phone)
VALUES ('Priya Sharma', 'seeker@test.com', 'seek123', 'SEEKER', '9123456780')
ON DUPLICATE KEY UPDATE name = name;

INSERT INTO jobs (employer_id, title, description, company_name, location, salary, job_type)
SELECT user_id, 'Java Developer', 'Looking for a Java developer with Swing/JDBC experience.',
       'TechSoft Solutions', 'Chennai', '4,00,000 - 6,00,000 PA', 'Full-Time'
FROM users WHERE email = 'employer@test.com';
