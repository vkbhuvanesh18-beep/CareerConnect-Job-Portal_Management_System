package com.jobportal.dao;

import com.jobportal.db.DBConnection;
import com.jobportal.model.Application;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ApplicationDAO {

    /** Returns true if applied successfully, false if already applied (duplicate) or on error. */
    public boolean applyToJob(int jobId, int seekerId) {
        if (hasApplied(jobId, seekerId)) {
            return false;
        }
        String sql = "INSERT INTO applications (job_id, seeker_id) VALUES (?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, jobId);
            ps.setInt(2, seekerId);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean hasApplied(int jobId, int seekerId) {
        String sql = "SELECT app_id FROM applications WHERE job_id = ? AND seeker_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, jobId);
            ps.setInt(2, seekerId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /** All applications submitted by one job seeker, with job details joined in. */
    public List<Application> getApplicationsBySeeker(int seekerId) {
        List<Application> list = new ArrayList<>();
        String sql = "SELECT a.*, j.title AS job_title, j.company_name " +
                     "FROM applications a JOIN jobs j ON a.job_id = j.job_id " +
                     "WHERE a.seeker_id = ? ORDER BY a.applied_date DESC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, seekerId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Application a = mapRow(rs);
                    a.setJobTitle(rs.getString("job_title"));
                    a.setCompanyName(rs.getString("company_name"));
                    list.add(a);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    /** All applicants for a specific job posting, with seeker details joined in (used by Employer). */
    public List<Application> getApplicationsByJob(int jobId) {
        List<Application> list = new ArrayList<>();
        String sql = "SELECT a.*, u.name AS seeker_name, u.email AS seeker_email " +
                     "FROM applications a JOIN users u ON a.seeker_id = u.user_id " +
                     "WHERE a.job_id = ? ORDER BY a.applied_date DESC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, jobId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Application a = mapRow(rs);
                    a.setSeekerName(rs.getString("seeker_name"));
                    a.setSeekerEmail(rs.getString("seeker_email"));
                    list.add(a);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    /** Employer shortlists or rejects an applicant. */
    public boolean updateStatus(int appId, String status) {
        String sql = "UPDATE applications SET status = ? WHERE app_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, status);
            ps.setInt(2, appId);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private Application mapRow(ResultSet rs) throws SQLException {
        Application a = new Application();
        a.setAppId(rs.getInt("app_id"));
        a.setJobId(rs.getInt("job_id"));
        a.setSeekerId(rs.getInt("seeker_id"));
        Timestamp ts = rs.getTimestamp("applied_date");
        a.setAppliedDate(ts != null ? ts.toString() : "");
        a.setStatus(rs.getString("status"));
        return a;
    }
}
