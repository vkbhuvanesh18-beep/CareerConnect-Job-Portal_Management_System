package com.jobportal;

import com.jobportal.ui.LoginFrame;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // Use the system look and feel so the UI matches the OS
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
            // fall back to default look and feel if system L&F is unavailable
        }

        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
