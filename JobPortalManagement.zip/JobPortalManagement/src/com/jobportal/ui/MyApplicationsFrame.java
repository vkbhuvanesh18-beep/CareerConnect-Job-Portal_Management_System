package com.jobportal.ui;

import com.jobportal.dao.ApplicationDAO;
import com.jobportal.model.Application;
import com.jobportal.model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class MyApplicationsFrame extends JFrame {

    public MyApplicationsFrame(User seeker) {
        setTitle("My Applications - " + seeker.getName());
        setSize(650, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        DefaultTableModel model = new DefaultTableModel(
                new String[]{"Job Title", "Company", "Applied On", "Status"}, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };
        JTable table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        ApplicationDAO applicationDAO = new ApplicationDAO();
        List<Application> applications = applicationDAO.getApplicationsBySeeker(seeker.getUserId());

        for (Application a : applications) {
            model.addRow(new Object[]{
                    a.getJobTitle(), a.getCompanyName(), a.getAppliedDate(), a.getStatus()
            });
        }

        if (applications.isEmpty()) {
            JLabel emptyLabel = new JLabel("You haven't applied to any jobs yet.", SwingConstants.CENTER);
            add(emptyLabel, BorderLayout.NORTH);
        }
    }
}
