package com.jobportal.ui;

import com.jobportal.dao.JobDAO;
import com.jobportal.model.Job;
import com.jobportal.model.User;

import javax.swing.*;
import java.awt.*;

public class PostJobFrame extends JFrame {

    private final User employer;
    private final EmployerDashboard parentDashboard;
    private final JobDAO jobDAO = new JobDAO();

    private JTextField titleField, locationField, salaryField;
    private JTextArea descriptionArea;
    private JComboBox<String> typeBox;

    public PostJobFrame(User employer, EmployerDashboard parentDashboard) {
        this.employer = employer;
        this.parentDashboard = parentDashboard;

        setTitle("Post a New Job");
        setSize(450, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(null);

        int y = 20;

        panel.add(makeLabel("Job Title:", y));
        titleField = new JTextField();
        titleField.setBounds(150, y, 250, 25);
        panel.add(titleField);
        y += 40;

        panel.add(makeLabel("Location:", y));
        locationField = new JTextField();
        locationField.setBounds(150, y, 250, 25);
        panel.add(locationField);
        y += 40;

        panel.add(makeLabel("Salary:", y));
        salaryField = new JTextField();
        salaryField.setBounds(150, y, 250, 25);
        panel.add(salaryField);
        y += 40;

        panel.add(makeLabel("Job Type:", y));
        typeBox = new JComboBox<>(new String[]{"Full-Time", "Part-Time", "Internship", "Contract"});
        typeBox.setBounds(150, y, 250, 25);
        panel.add(typeBox);
        y += 40;

        panel.add(makeLabel("Description:", y));
        y += 25;
        descriptionArea = new JTextArea();
        descriptionArea.setLineWrap(true);
        descriptionArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(descriptionArea);
        scrollPane.setBounds(30, y, 370, 130);
        panel.add(scrollPane);
        y += 150;

        JButton postBtn = new JButton("Post Job");
        postBtn.setBackground(new Color(39, 174, 96));
        postBtn.setForeground(Color.WHITE);
        postBtn.setBounds(150, y, 130, 30);
        panel.add(postBtn);

        add(panel);

        postBtn.addActionListener(e -> submitJob());
    }

    private JLabel makeLabel(String text, int y) {
        JLabel label = new JLabel(text);
        label.setBounds(20, y, 120, 25);
        return label;
    }

    private void submitJob() {
        String title = titleField.getText().trim();
        String location = locationField.getText().trim();
        String salary = salaryField.getText().trim();
        String description = descriptionArea.getText().trim();
        String type = (String) typeBox.getSelectedItem();

        if (title.isEmpty() || location.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Job title and location are required.",
                    "Missing Information", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Job job = new Job();
        job.setEmployerId(employer.getUserId());
        job.setTitle(title);
        job.setDescription(description);
        job.setCompanyName(employer.getCompanyName());
        job.setLocation(location);
        job.setSalary(salary);
        job.setJobType(type);

        boolean success = jobDAO.postJob(job);

        if (success) {
            JOptionPane.showMessageDialog(this, "Job posted successfully!");
            parentDashboard.loadMyJobs();
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to post job. Please try again.",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
