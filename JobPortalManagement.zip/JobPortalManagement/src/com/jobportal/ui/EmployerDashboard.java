package com.jobportal.ui;

import com.jobportal.dao.ApplicationDAO;
import com.jobportal.dao.JobDAO;
import com.jobportal.model.Application;
import com.jobportal.model.Job;
import com.jobportal.model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class EmployerDashboard extends JFrame {

    private final User employer;
    private final JobDAO jobDAO = new JobDAO();
    private final ApplicationDAO applicationDAO = new ApplicationDAO();

    private DefaultTableModel jobTableModel;
    private JTable jobTable;

    private DefaultTableModel applicantTableModel;
    private JTable applicantTable;

    public EmployerDashboard(User employer) {
        this.employer = employer;

        setTitle("Employer Dashboard - " + employer.getCompanyName());
        setSize(850, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new BorderLayout());
        JLabel welcome = new JLabel("  " + employer.getName() + " | " + employer.getCompanyName());
        welcome.setFont(new Font("SansSerif", Font.BOLD, 13));
        JButton logoutBtn = new JButton("Logout");
        logoutBtn.addActionListener(e -> {
            new LoginFrame().setVisible(true);
            dispose();
        });
        topPanel.add(welcome, BorderLayout.WEST);
        topPanel.add(logoutBtn, BorderLayout.EAST);
        add(topPanel, BorderLayout.NORTH);

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, buildJobsPanel(), buildApplicantsPanel());
        splitPane.setResizeWeight(0.5);
        add(splitPane, BorderLayout.CENTER);

        loadMyJobs();
    }

    private JPanel buildJobsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("My Job Postings"));

        jobTableModel = new DefaultTableModel(
                new String[]{"ID", "Title", "Location", "Salary", "Type", "Posted On"}, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };
        jobTable = new JTable(jobTableModel);
        jobTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) loadApplicantsForSelectedJob();
        });
        panel.add(new JScrollPane(jobTable), BorderLayout.CENTER);

        JButton postJobBtn = new JButton("Post New Job");
        postJobBtn.setBackground(new Color(41, 128, 185));
        postJobBtn.setForeground(Color.WHITE);
        postJobBtn.addActionListener(e -> {
            PostJobFrame frame = new PostJobFrame(employer, this);
            frame.setVisible(true);
        });

        JButton deleteBtn = new JButton("Delete Selected Job");
        deleteBtn.addActionListener(e -> deleteSelectedJob());

        JButton refreshBtn = new JButton("Refresh");
        refreshBtn.addActionListener(e -> loadMyJobs());

        JPanel bottom = new JPanel();
        bottom.add(postJobBtn);
        bottom.add(deleteBtn);
        bottom.add(refreshBtn);
        panel.add(bottom, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel buildApplicantsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Applicants for Selected Job"));

        applicantTableModel = new DefaultTableModel(
                new String[]{"App ID", "Applicant Name", "Email", "Applied On", "Status"}, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };
        applicantTable = new JTable(applicantTableModel);
        panel.add(new JScrollPane(applicantTable), BorderLayout.CENTER);

        JButton shortlistBtn = new JButton("Shortlist");
        shortlistBtn.addActionListener(e -> updateSelectedStatus("SHORTLISTED"));

        JButton rejectBtn = new JButton("Reject");
        rejectBtn.addActionListener(e -> updateSelectedStatus("REJECTED"));

        JPanel bottom = new JPanel();
        bottom.add(shortlistBtn);
        bottom.add(rejectBtn);
        panel.add(bottom, BorderLayout.SOUTH);

        return panel;
    }

    /** Called by PostJobFrame after a successful post. */
    public void loadMyJobs() {
        jobTableModel.setRowCount(0);
        List<Job> jobs = jobDAO.getJobsByEmployer(employer.getUserId());
        for (Job j : jobs) {
            jobTableModel.addRow(new Object[]{
                    j.getJobId(), j.getTitle(), j.getLocation(), j.getSalary(),
                    j.getJobType(), j.getPostedDate()
            });
        }
        applicantTableModel.setRowCount(0);
    }

    private void loadApplicantsForSelectedJob() {
        applicantTableModel.setRowCount(0);
        int row = jobTable.getSelectedRow();
        if (row == -1) return;

        int jobId = (int) jobTableModel.getValueAt(row, 0);
        List<Application> applications = applicationDAO.getApplicationsByJob(jobId);
        for (Application a : applications) {
            applicantTableModel.addRow(new Object[]{
                    a.getAppId(), a.getSeekerName(), a.getSeekerEmail(),
                    a.getAppliedDate(), a.getStatus()
            });
        }
    }

    private void updateSelectedStatus(String status) {
        int row = applicantTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select an applicant first.");
            return;
        }
        int appId = (int) applicantTableModel.getValueAt(row, 0);
        applicationDAO.updateStatus(appId, status);
        loadApplicantsForSelectedJob();
    }

    private void deleteSelectedJob() {
        int row = jobTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a job first.");
            return;
        }
        int jobId = (int) jobTableModel.getValueAt(row, 0);

        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete this job posting and all its applications?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            jobDAO.deleteJob(jobId);
            loadMyJobs();
        }
    }
}
