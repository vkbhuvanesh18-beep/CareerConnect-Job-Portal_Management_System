package com.jobportal.ui;

import com.jobportal.dao.ApplicationDAO;
import com.jobportal.dao.JobDAO;
import com.jobportal.model.Job;
import com.jobportal.model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class JobSeekerDashboard extends JFrame {

    private final User seeker;
    private final JobDAO jobDAO = new JobDAO();
    private final ApplicationDAO applicationDAO = new ApplicationDAO();

    private DefaultTableModel jobTableModel;
    private JTable jobTable;
    private JTextField searchField;

    public JobSeekerDashboard(User seeker) {
        this.seeker = seeker;

        setTitle("Job Seeker Dashboard - " + seeker.getName());
        setSize(850, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new BorderLayout());
        JLabel welcome = new JLabel("  Welcome, " + seeker.getName());
        welcome.setFont(new Font("SansSerif", Font.BOLD, 13));

        JPanel rightTop = new JPanel();
        JButton myApplicationsBtn = new JButton("My Applications");
        myApplicationsBtn.addActionListener(e -> new MyApplicationsFrame(seeker).setVisible(true));
        JButton logoutBtn = new JButton("Logout");
        logoutBtn.addActionListener(e -> {
            new LoginFrame().setVisible(true);
            dispose();
        });
        rightTop.add(myApplicationsBtn);
        rightTop.add(logoutBtn);

        topPanel.add(welcome, BorderLayout.WEST);
        topPanel.add(rightTop, BorderLayout.EAST);
        add(topPanel, BorderLayout.NORTH);

        add(buildJobsPanel(), BorderLayout.CENTER);

        loadAllJobs();
    }

    private JPanel buildJobsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Available Jobs"));

        JPanel searchPanel = new JPanel();
        searchField = new JTextField(25);
        JButton searchBtn = new JButton("Search");
        JButton clearBtn = new JButton("Show All");
        searchPanel.add(new JLabel("Search by title or location:"));
        searchPanel.add(searchField);
        searchPanel.add(searchBtn);
        searchPanel.add(clearBtn);
        panel.add(searchPanel, BorderLayout.NORTH);

        jobTableModel = new DefaultTableModel(
                new String[]{"ID", "Title", "Company", "Location", "Salary", "Type", "Description"}, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };
        jobTable = new JTable(jobTableModel);
        // hide the description column width to keep table readable, still shown in detail dialog
        jobTable.getColumnModel().getColumn(6).setPreferredWidth(0);
        panel.add(new JScrollPane(jobTable), BorderLayout.CENTER);

        JButton applyBtn = new JButton("Apply to Selected Job");
        applyBtn.setBackground(new Color(41, 128, 185));
        applyBtn.setForeground(Color.WHITE);
        applyBtn.addActionListener(e -> applyToSelectedJob());

        JButton viewDetailsBtn = new JButton("View Details");
        viewDetailsBtn.addActionListener(e -> viewSelectedJobDetails());

        JPanel bottom = new JPanel();
        bottom.add(viewDetailsBtn);
        bottom.add(applyBtn);
        panel.add(bottom, BorderLayout.SOUTH);

        searchBtn.addActionListener(e -> {
            String keyword = searchField.getText().trim();
            if (keyword.isEmpty()) {
                loadAllJobs();
            } else {
                loadJobs(jobDAO.searchJobs(keyword));
            }
        });
        clearBtn.addActionListener(e -> {
            searchField.setText("");
            loadAllJobs();
        });

        return panel;
    }

    private void loadAllJobs() {
        loadJobs(jobDAO.getAllJobs());
    }

    private void loadJobs(List<Job> jobs) {
        jobTableModel.setRowCount(0);
        for (Job j : jobs) {
            jobTableModel.addRow(new Object[]{
                    j.getJobId(), j.getTitle(), j.getCompanyName(), j.getLocation(),
                    j.getSalary(), j.getJobType(), j.getDescription()
            });
        }
    }

    private void viewSelectedJobDetails() {
        int row = jobTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a job first.");
            return;
        }
        String title = (String) jobTableModel.getValueAt(row, 1);
        String company = (String) jobTableModel.getValueAt(row, 2);
        String location = (String) jobTableModel.getValueAt(row, 3);
        String salary = (String) jobTableModel.getValueAt(row, 4);
        String type = (String) jobTableModel.getValueAt(row, 5);
        String description = (String) jobTableModel.getValueAt(row, 6);

        String message = "Title: " + title +
                "\nCompany: " + company +
                "\nLocation: " + location +
                "\nSalary: " + salary +
                "\nType: " + type +
                "\n\nDescription:\n" + (description == null || description.isEmpty() ? "N/A" : description);

        JTextArea textArea = new JTextArea(message, 12, 40);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setEditable(false);
        JOptionPane.showMessageDialog(this, new JScrollPane(textArea), "Job Details", JOptionPane.INFORMATION_MESSAGE);
    }

    private void applyToSelectedJob() {
        int row = jobTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a job first.");
            return;
        }
        int jobId = (int) jobTableModel.getValueAt(row, 0);

        boolean success = applicationDAO.applyToJob(jobId, seeker.getUserId());

        if (success) {
            JOptionPane.showMessageDialog(this, "Application submitted successfully!");
        } else {
            JOptionPane.showMessageDialog(this, "You have already applied to this job.",
                    "Already Applied", JOptionPane.WARNING_MESSAGE);
        }
    }
}
