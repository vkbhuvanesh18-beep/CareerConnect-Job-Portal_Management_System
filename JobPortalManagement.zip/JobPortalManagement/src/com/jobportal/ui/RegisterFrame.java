package com.jobportal.ui;

import com.jobportal.dao.UserDAO;
import com.jobportal.model.User;

import javax.swing.*;
import java.awt.*;

public class RegisterFrame extends JFrame {

    private JTextField nameField, emailField, phoneField, companyField;
    private JPasswordField passwordField;
    private JComboBox<String> roleBox;
    private JLabel companyLabel;

    public RegisterFrame() {
        setTitle("Job Portal - Register New Account");
        setSize(430, 430);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);

        JLabel heading = new JLabel("Create a New Account");
        heading.setFont(new Font("SansSerif", Font.BOLD, 16));
        heading.setBounds(40, 15, 300, 30);
        panel.add(heading);

        int y = 60;

        panel.add(makeLabel("Register As:", y));
        roleBox = new JComboBox<>(new String[]{"EMPLOYER", "SEEKER"});
        roleBox.setBounds(160, y, 200, 25);
        panel.add(roleBox);
        y += 40;

        panel.add(makeLabel("Full Name:", y));
        nameField = new JTextField();
        nameField.setBounds(160, y, 200, 25);
        panel.add(nameField);
        y += 40;

        panel.add(makeLabel("Email:", y));
        emailField = new JTextField();
        emailField.setBounds(160, y, 200, 25);
        panel.add(emailField);
        y += 40;

        panel.add(makeLabel("Password:", y));
        passwordField = new JPasswordField();
        passwordField.setBounds(160, y, 200, 25);
        panel.add(passwordField);
        y += 40;

        panel.add(makeLabel("Phone:", y));
        phoneField = new JTextField();
        phoneField.setBounds(160, y, 200, 25);
        panel.add(phoneField);
        y += 40;

        companyLabel = makeLabel("Company Name:", y);
        panel.add(companyLabel);
        companyField = new JTextField();
        companyField.setBounds(160, y, 200, 25);
        panel.add(companyField);
        y += 50;

        JButton registerBtn = new JButton("Register");
        registerBtn.setBounds(90, y, 110, 30);
        registerBtn.setBackground(new Color(39, 174, 96));
        registerBtn.setForeground(Color.WHITE);
        panel.add(registerBtn);

        JButton backBtn = new JButton("Back to Login");
        backBtn.setBounds(210, y, 130, 30);
        panel.add(backBtn);

        add(panel);

        // company field only makes sense for employers
        roleBox.addActionListener(e -> toggleCompanyField());
        toggleCompanyField();

        registerBtn.addActionListener(e -> attemptRegister());
        backBtn.addActionListener(e -> {
            new LoginFrame().setVisible(true);
            dispose();
        });
    }

    private void toggleCompanyField() {
        boolean isEmployer = "EMPLOYER".equals(roleBox.getSelectedItem());
        companyLabel.setVisible(isEmployer);
        companyField.setVisible(isEmployer);
    }

    private JLabel makeLabel(String text, int y) {
        JLabel label = new JLabel(text);
        label.setBounds(30, y, 130, 25);
        return label;
    }

    private void attemptRegister() {
        String name = nameField.getText().trim();
        String email = emailField.getText().trim();
        String password = new String(passwordField.getPassword());
        String phone = phoneField.getText().trim();
        String role = (String) roleBox.getSelectedItem();
        String company = "EMPLOYER".equals(role) ? companyField.getText().trim() : null;

        if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Name, email and password are required.",
                    "Missing Information", JOptionPane.WARNING_MESSAGE);
            return;
        }

        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setPassword(password);
        user.setRole(role);
        user.setPhone(phone);
        user.setCompanyName(company);

        UserDAO userDAO = new UserDAO();
        boolean success = userDAO.registerUser(user);

        if (success) {
            JOptionPane.showMessageDialog(this, "Registration successful! Please login.");
            new LoginFrame().setVisible(true);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Registration failed. Email may already be in use.",
                    "Registration Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
