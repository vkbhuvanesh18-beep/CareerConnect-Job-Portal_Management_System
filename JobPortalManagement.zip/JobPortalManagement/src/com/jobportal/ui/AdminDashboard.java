package com.jobportal.ui;

import com.jobportal.dao.JobDAO;
import com.jobportal.dao.UserDAO;
import com.jobportal.model.Job;
import com.jobportal.model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class AdminDashboard extends JFrame {

    private final User admin;
    private final UserDAO userDAO = new UserDAO();
    private final JobDAO jobDAO = new JobDAO();

    private DefaultTableModel userTableModel;
    private DefaultTableModel jobTableModel;
    private JTable userTable;
    private JTable jobTable;

    public AdminDashboard(User admin) {
        this.admin = admin;

        setTitle("Admin Dashboard - " + admin.getName());
        setSize(800, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Manage Users", buildUsersPanel());
        tabs.addTab("Manage Jobs", buildJobsPanel());

        JPanel topPanel = new JPanel(new BorderLayout());
        JLabel welcome = new JLabel("  Logged in as Admin: " + admin.getName());
        welcome.setFont(new Font("SansSerif", Font.BOLD, 13));
        JButton logoutBtn = new JButton("Logout");
        logoutBtn.addActionListener(e -> {
            new LoginFrame().setVisible(true);
            dispose();
        });
        topPanel.add(welcome, BorderLayout.WEST);
        topPanel.add(logoutBtn, BorderLayout.EAST);

        setLayout(new BorderLayout());
        add(topPanel, BorderLayout.NORTH);
        add(tabs, BorderLayout.CENTER);

        loadUsers();
        loadJobs();
    }

    private JPanel buildUsersPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        userTableModel = new DefaultTableModel(
                new String[]{"ID", "Name", "Email", "Role", "Phone", "Company"}, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };
        userTable = new JTable(userTableModel);
        panel.add(new JScrollPane(userTable), BorderLayout.CENTER);

        JButton deleteBtn = new JButton("Delete Selected User");
        deleteBtn.addActionListener(e -> deleteSelectedUser());

        JButton refreshBtn = new JButton("Refresh");
        refreshBtn.addActionListener(e -> loadUsers());

        JPanel bottom = new JPanel();
        bottom.add(deleteBtn);
        bottom.add(refreshBtn);
        panel.add(bottom, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel buildJobsPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        jobTableModel = new DefaultTableModel(
                new String[]{"ID", "Title", "Company", "Location", "Salary", "Type", "Posted On"}, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };
        jobTable = new JTable(jobTableModel);
        panel.add(new JScrollPane(jobTable), BorderLayout.CENTER);

        JButton deleteBtn = new JButton("Delete Selected Job");
        deleteBtn.addActionListener(e -> deleteSelectedJob());

        JButton refreshBtn = new JButton("Refresh");
        refreshBtn.addActionListener(e -> loadJobs());

        JPanel bottom = new JPanel();
        bottom.add(deleteBtn);
        bottom.add(refreshBtn);
        panel.add(bottom, BorderLayout.SOUTH);

        return panel;
    }

    private void loadUsers() {
        userTableModel.setRowCount(0);
        List<User> users = userDAO.getAllUsers();
        for (User u : users) {
            userTableModel.addRow(new Object[]{
                    u.getUserId(), u.getName(), u.getEmail(), u.getRole(),
                    u.getPhone(), u.getCompanyName() == null ? "-" : u.getCompanyName()
            });
        }
    }

    private void loadJobs() {
        jobTableModel.setRowCount(0);
        List<Job> jobs = jobDAO.getAllJobs();
        for (Job j : jobs) {
            jobTableModel.addRow(new Object[]{
                    j.getJobId(), j.getTitle(), j.getCompanyName(), j.getLocation(),
                    j.getSalary(), j.getJobType(), j.getPostedDate()
            });
        }
    }

    private void deleteSelectedUser() {
        int row = userTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a user first.");
            return;
        }
        int userId = (int) userTableModel.getValueAt(row, 0);
        String role = (String) userTableModel.getValueAt(row, 3);

        if ("ADMIN".equals(role)) {
            JOptionPane.showMessageDialog(this, "You cannot delete an Admin account.",
                    "Not Allowed", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete this user? Their jobs/applications will also be removed.",
                "Confirm Delete", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            userDAO.deleteUser(userId);
            loadUsers();
            loadJobs();
        }
    }

    private void deleteSelectedJob() {
        int row = jobTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a job first.");
            return;
        }
        int jobId = (int) jobTableModel.getValueAt(row, 0);

        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete this job posting?", "Confirm Delete", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            jobDAO.deleteJob(jobId);
            loadJobs();
        }
    }
}
