package com.jobportal.ui;

import com.jobportal.dao.UserDAO;
import com.jobportal.model.User;

import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {

    private JTextField emailField;
    private JPasswordField passwordField;
    private JComboBox<String> roleBox;

    public LoginFrame() {
        setTitle("Job Portal Management System - Login");
        setSize(420, 340);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(235, 245, 251));

        JLabel heading = new JLabel("Job Portal Management System");
        heading.setFont(new Font("SansSerif", Font.BOLD, 16));
        heading.setBounds(40, 15, 340, 30);
        panel.add(heading);

        JLabel roleLabel = new JLabel("Login As:");
        roleLabel.setBounds(40, 70, 100, 25);
        panel.add(roleLabel);

        roleBox = new JComboBox<>(new String[]{"ADMIN", "EMPLOYER", "SEEKER"});
        roleBox.setBounds(150, 70, 200, 25);
        panel.add(roleBox);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(40, 110, 100, 25);
        panel.add(emailLabel);

        emailField = new JTextField();
        emailField.setBounds(150, 110, 200, 25);
        panel.add(emailField);

        JLabel passLabel = new JLabel("Password:");
        passLabel.setBounds(40, 150, 100, 25);
        panel.add(passLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(150, 150, 200, 25);
        panel.add(passwordField);

        JButton loginBtn = new JButton("Login");
        loginBtn.setBounds(80, 200, 100, 30);
        loginBtn.setBackground(new Color(41, 128, 185));
        loginBtn.setForeground(Color.WHITE);
        panel.add(loginBtn);

        JButton registerBtn = new JButton("Register");
        registerBtn.setBounds(210, 200, 120, 30);
        panel.add(registerBtn);

        JLabel hint = new JLabel("Default admin: admin@jobportal.com / admin123");
        hint.setFont(new Font("SansSerif", Font.ITALIC, 11));
        hint.setForeground(Color.GRAY);
        hint.setBounds(40, 250, 340, 20);
        panel.add(hint);

        add(panel);

        loginBtn.addActionListener(e -> attemptLogin());
        registerBtn.addActionListener(e -> {
            new RegisterFrame().setVisible(true);
            dispose();
        });
    }

    private void attemptLogin() {
        String email = emailField.getText().trim();
        String password = new String(passwordField.getPassword());
        String role = (String) roleBox.getSelectedItem();

        if (email.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both email and password.",
                    "Missing Information", JOptionPane.WARNING_MESSAGE);
            return;
        }

        UserDAO userDAO = new UserDAO();
        User user = userDAO.login(email, password, role);

        if (user == null) {
            JOptionPane.showMessageDialog(this, "Invalid credentials or role selected.",
                    "Login Failed", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JOptionPane.showMessageDialog(this, "Welcome, " + user.getName() + "!");

        switch (role) {
            case "ADMIN":
                new AdminDashboard(user).setVisible(true);
                break;
            case "EMPLOYER":
                new EmployerDashboard(user).setVisible(true);
                break;
            case "SEEKER":
                new JobSeekerDashboard(user).setVisible(true);
                break;
        }
        dispose();
    }
}
