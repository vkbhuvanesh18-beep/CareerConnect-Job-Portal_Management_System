# Job Portal Management System (Java + Swing + JDBC + MySQL)

A desktop application built for a PT-1 college project. It supports three roles:

- **Admin** — view/delete users, view/delete job postings
- **Employer** — post jobs, view applicants, shortlist/reject applicants
- **Job Seeker** — search/browse jobs, apply, track application status

Tested and compiled successfully with **JDK 21** (also works with JDK 8+).

---

## 1. Project Structure

```
JobPortalManagement/
├── database/
│   └── job_portal_db.sql          <- run this in MySQL first
├── lib/
│   └── (put mysql-connector-j-x.x.x.jar here)
├── src/com/jobportal/
│   ├── Main.java                  <- entry point
│   ├── db/DBConnection.java       <- JDBC connection
│   ├── model/                     <- User, Job, Application (POJOs)
│   ├── dao/                       <- UserDAO, JobDAO, ApplicationDAO (SQL logic)
│   └── ui/                        <- all Swing screens
└── README.md
```

## 2. Prerequisites

1. **JDK 8 or higher** installed (`java -version` / `javac -version` to confirm).
2. **MySQL Server** installed and running (MySQL 5.7+ or 8.x).
3. **MySQL Connector/J** (JDBC driver) — download the jar:
   - https://dev.mysql.com/downloads/connector/j/
   - Choose "Platform Independent" → download the `.zip` or `.tar.gz`
   - Extract it and copy `mysql-connector-j-x.x.x.jar` into the `lib/` folder of this project.

## 3. Step-by-Step Setup

### Step 1 — Create the database
Open MySQL Workbench, phpMyAdmin, or the terminal and run the script:

```bash
mysql -u root -p < database/job_portal_db.sql
```

This creates the `job_portal_db` database with three tables (`users`, `jobs`, `applications`) and inserts:
- A default **Admin** login → `admin@jobportal.com` / `admin123`
- A sample **Employer** login → `employer@test.com` / `emp123`
- A sample **Job Seeker** login → `seeker@test.com` / `seek123`
- One sample job posting

### Step 2 — Configure the DB connection
Open `src/com/jobportal/db/DBConnection.java` and update these two lines with your own MySQL credentials:

```java
private static final String DB_USER = "root";
private static final String DB_PASSWORD = "root"; // <-- put your actual MySQL password here
```

### Step 3 — Compile the project

**Windows (Command Prompt), from the project root folder:**
```bat
javac -d bin -cp "lib\mysql-connector-j-8.4.0.jar" src\com\jobportal\Main.java src\com\jobportal\db\*.java src\com\jobportal\model\*.java src\com\jobportal\dao\*.java src\com\jobportal\ui\*.java
```

**Linux / macOS, from the project root folder:**
```bash
javac -d bin -cp "lib/mysql-connector-j-8.4.0.jar" src/com/jobportal/Main.java src/com/jobportal/db/*.java src/com/jobportal/model/*.java src/com/jobportal/dao/*.java src/com/jobportal/ui/*.java
```

> Replace `mysql-connector-j-8.4.0.jar` with whatever version filename you actually downloaded.

If you're using an IDE (Eclipse / IntelliJ / NetBeans), simpler option:
1. Create a new Java project and copy the `src` folder content in as your source root.
2. Right-click the project → Add External JAR → select the mysql-connector jar from `lib/`.
3. Run `Main.java`.

### Step 4 — Run the project

**Windows:**
```bat
java -cp "bin;lib\mysql-connector-j-8.4.0.jar" com.jobportal.Main
```

**Linux / macOS:**
```bash
java -cp "bin:lib/mysql-connector-j-8.4.0.jar" com.jobportal.Main
```

The login window should open. Use any of the sample logins above, or register a new Employer/Job Seeker account.

## 4. How to Use / Demo Flow (for your viva/project demo)

1. **Login as Admin** (`admin@jobportal.com` / `admin123`) → show the Manage Users and Manage Jobs tabs.
2. **Register a new Employer** → login as that employer → click "Post New Job" → fill the form → submit.
3. **Register a new Job Seeker** → login → search for the job you just posted → click "Apply to Selected Job".
4. **Login back as the Employer** → select the job → see the applicant appear in the bottom table → click "Shortlist".
5. **Login back as the Job Seeker** → click "My Applications" → see the status updated to "SHORTLISTED".

## 5. Common Issues

| Problem | Fix |
|---|---|
| "Driver Error" popup on launch | The mysql-connector jar isn't on the classpath — check Step 3/4 command. |
| "Connection Error" popup | MySQL service isn't running, or wrong username/password in `DBConnection.java`. |
| `Unknown database 'job_portal_db'` | You skipped Step 1 — run the SQL script first. |
| Port 3306 refused | Confirm MySQL is running: `services.msc` (Windows) or `sudo systemctl status mysql` (Linux). |

## 6. Ideas for Extending (bonus points for viva)

- Add password hashing (e.g. BCrypt) instead of storing plain text passwords.
- Add resume upload (store file path in DB, open with `Desktop.getDesktop().open()`).
- Add email notifications when an application status changes.
- Add pagination / filters (salary range, job type) to the search screen.
- Export the applicant list to CSV/PDF from the Employer dashboard.
